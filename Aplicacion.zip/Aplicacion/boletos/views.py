from django.http.response import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse
from boletos.models import Articulos
from boletos.models import datos
from boletos.models import clientes

# Create your views here.

def busqueda_boletos(request):
    return render(request, "busqueda_boletos.html")

def buscar(request):
    if request.GET["prd"]:
        #mensaje="Boletos a la Venta: %r" %request.GET["prd"]
        producto=request.GET["prd"]
        boletos=Articulos.objects.filter(nombre__icontains=producto)
        return render(request, "resultados_busqueda.html",{"boletos":boletos, "query":producto})
    else:
        mensaje="No has introducido nada"

    return HttpResponse(mensaje)

def contacto(request):
    if request.method=="POST":
        return render(request, "gracias.html")
        
    return render(request, "contacto.html")


def inicio_usuario(request):
    if request.method=="POST":
        return render(request, "aplicacion.html")
        
    return render(request, "login.html")

def servicios(request):
    return render(request, "gracias.html")

def total_servicios(request):
    return render(request, "operacion.html")
#def inicio_usuario(request):
 #   if request.POST["usuario"]:
  #      #mensaje="Boletos a la Venta: %r" %request.GET["prd"]
   #     inicio1=request.POST["usuario"]
    #    logon=clientes.objects.filter(nombre__icontains=inicio1)
     #   return render(request, "login.html",{"logon":logon, "query":inicio1})
#    else:
 #       mensaje="No has introducido nada"

   # return HttpResponse(mensaje)

