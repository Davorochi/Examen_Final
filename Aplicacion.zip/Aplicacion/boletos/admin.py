from django.contrib import admin
from boletos.models import clientes, Articulos, Pedidos, datos

class clientesadmin(admin.ModelAdmin):
    list_display=("nombre","direccion","email","tfno")
    search_fields=("nombre","tfno")

class datosadmin(admin.ModelAdmin):
    list_filter=("clase",)

class pedidosadmin(admin.ModelAdmin):
    list_display=("numero","fecha")
    list_filter=("fecha",)
    date_hierarchy="fecha"

admin.site.register(clientes, clientesadmin)
admin.site.register(Articulos)
admin.site.register(Pedidos,pedidosadmin)
admin.site.register(datos, datosadmin)

# Register your models here.
