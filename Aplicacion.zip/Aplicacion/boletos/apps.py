from django.apps import AppConfig


class BoletosConfig(AppConfig):
    name = 'boletos'
