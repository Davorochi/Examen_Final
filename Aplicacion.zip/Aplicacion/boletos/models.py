from django.db import models
from django.db.models.base import Model

class clientes(models.Model):
    nombre=models.CharField(max_length=30)
    direccion=models.CharField(max_length=50)
    email=models.EmailField(blank=True, null=True)
    tfno=models.CharField(max_length=8)
    
    def __str__(self):
        return self.nombre

class Articulos(models.Model):
    nombre=models.CharField(max_length=30, verbose_name="Tipo de boleto")
    seccion=models.CharField(max_length=20, verbose_name= "Servicio")

    def __str__(self):
        return 'Boleto %s con servicio %s' %(self.nombre, self.seccion)

class Pedidos(models.Model):
    numero=models.IntegerField(verbose_name="Cantidad")
    fecha=models.DateField()
    entregado=models.BooleanField()


class datos(models.Model):
    clase=models.CharField(max_length=30)
    factura=models.CharField(max_length=50)
    subtotal=models.IntegerField()
    descuento=models.IntegerField()
    Total=models.IntegerField()

    def __str__(self):
        return 'La clase que escogio es %s con numero de factura %s , el subtotal es Q %s con un descuento de Q %s, el total es Q %s ' %(self.clase, self.factura, self.subtotal, self.descuento, self.Total)


# Create your models here.
